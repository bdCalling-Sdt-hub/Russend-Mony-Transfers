import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:money_transfers/models/hidden_fee_model.dart';

import '../global/api_url.dart';
import '../services/api_services/api_services.dart';

class AddTransactionsController extends GetxController {

}

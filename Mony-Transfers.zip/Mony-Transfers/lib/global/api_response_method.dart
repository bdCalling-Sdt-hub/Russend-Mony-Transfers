class ApiResponseMethod{

  static const String getMethod = "get";
  static const String postMethod = "post";
  static const String updateMethod = "update";
  static const String deleteMethod = "delete";
}